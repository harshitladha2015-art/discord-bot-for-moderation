const {
  Client,
  GatewayIntentBits,
  Partials,
  EmbedBuilder,
  AttachmentBuilder,
  ActivityType,
  ChannelType,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ComponentType,
  REST,
  Routes
} = require("discord.js");

const client = new Client({
  partials: [Partials.Message, Partials.Channel, Partials.Reaction],
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMessageReactions,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildVoiceStates
  ]
});

const config = require("./config.json");
const express = require("express");
const app = express();
const fs = require("fs");
const path = require("path");

const port = Number(process.env.PORT || 3000);
const ANNOUNCEMENTS_CHANNEL_ID = "1553419627973841116";
const PROOF_CHANNEL_ID = "1553371496838078548";
const PANEL_COMMANDS = [
  { name: "panel", description: "Send the invite panel" },
  { name: "panel-2", description: "Send the Nitro request panel" },
  { name: "leaderboard", description: "Show the invite leaderboard" },
  { name: "dock", description: "Create or update a member-count voice channel" },
  {
    name: "giveaway",
    description: "Manage giveaways",
    options: [
      {
        name: "start",
        description: "Start a giveaway",
        type: 1,
        options: [
          { name: "duration", description: "Example: 2h, 30m", type: 3, required: true },
          { name: "winners", description: "Number of winners", type: 4, required: true },
          { name: "prize", description: "Prize name", type: 3, required: true },
          { name: "invites", description: "Required invite count", type: 4, required: true }
        ]
      }
    ]
  }
];
const dockChannels = new Map();
let datatosend = "";

function getAnnouncementsRole(guild) {
  return guild?.roles.cache.find(role => /announcements/i.test(role.name)) || null;
}

function getProofRole(guild) {
  return guild?.roles.cache.find(role => /proof/i.test(role.name)) || null;
}

function buildNitroClaimMessage(user, inviteCount) {
  return inviteCount >= 2
    ? `Hello ${user}, your Nitro is on the way. Because there is a lot of demand, it will take 7 days for it to be delivered, if you would like instant claim, invite 2 more people to the server and claim it instantly.`
    : `Sorry, you don't have enough active invites to claim Nitro. You currently have ${inviteCount}; you need 2.`;
}

function getDockName(memberCount) {
  return `Members: ${memberCount}`;
}

async function updateDockChannel(channel) {
  if (!channel || channel.type !== ChannelType.GuildVoice) return;

  const memberCount = channel.guild ? channel.guild.memberCount : 0;
  await channel.setName(getDockName(memberCount)).catch(() => {});
}

async function ensureDockChannel(guild, originChannel) {
  if (!guild) return null;

  const existingId = dockChannels.get(guild.id);
  if (existingId) {
    const existing = guild.channels.cache.get(existingId) || await guild.channels.fetch(existingId).catch(() => null);
    if (existing && existing.type === ChannelType.GuildVoice) {
      await updateDockChannel(existing);
      return existing;
    }
    dockChannels.delete(guild.id);
  }

  const created = await guild.channels.create({
    name: getDockName(0),
    type: ChannelType.GuildVoice,
    parent: originChannel && originChannel.parentId ? originChannel.parentId : null,
    reason: "Dock channel created by /dock command"
  }).catch(() => null);

  if (!created) return null;
  dockChannels.set(guild.id, created.id);
  await updateDockChannel(created);
  return created;
}

app.get("/font", function (e, t) {
  const a = `${__dirname}/Whitneyfont.woff`;
  t.sendFile(a);
});
app.get("/nitroboost.png", function (e, t) {
  t.sendFile(`${__dirname}/images/1.PNG`);
});
app.get("/nitroclassic.png", function (e, t) {
  t.sendFile(`${__dirname}/images/2.PNG`);
});
app.get("/", function (e, t) {
  t.send(datatosend);
});

const renderServer = app.listen(port, () => {
  console.log(`Renderer listening at http://localhost:${port}`);
});

const inviteTrackerFile = path.join(__dirname, "invite-tracker.json");
let inviteTracker = loadInviteTracker();
let inviteTrackerWrite = Promise.resolve();

function loadInviteTracker() {
  try {
    const saved = JSON.parse(fs.readFileSync(inviteTrackerFile, "utf8"));
    return saved && saved.guilds ? saved : { guilds: {} };
  } catch (error) {
    return { guilds: {} };
  }
}

function getInviteState(guildId) {
  if (!inviteTracker.guilds[guildId]) {
    inviteTracker.guilds[guildId] = {
      initialized: false,
      invites: {},
      members: {},
      manualInvites: {}
    };
  }

  const state = inviteTracker.guilds[guildId];
  state.invites = state.invites || {};
  state.members = state.members || {};
  state.manualInvites = state.manualInvites || {};
  return state;
}

function saveInviteTracker() {
  inviteTrackerWrite = inviteTrackerWrite
    .catch(() => {})
    .then(() =>
      fs.promises.writeFile(
        inviteTrackerFile,
        JSON.stringify(inviteTracker, null, 2)
      )
    )
    .catch(error => console.error("Could not save invite tracker:", error));
  return inviteTrackerWrite;
}

async function fetchInviteSnapshot(guild) {
  if (!guild || typeof guild.fetchInvites !== "function") {
    return null;
  }

  const invites = await guild.fetchInvites().catch(() => null);
  if (!invites) return null;

  const snapshot = {};
  invites.forEach(invite => {
    snapshot[invite.code] = {
      uses: invite.uses || 0,
      inviterId: invite.inviter ? invite.inviter.id : null
    };
  });
  return snapshot;
}

async function initializeInviteTracking(guild) {
  if (!guild || typeof guild.fetchInvites !== "function") return;

  const snapshot = await fetchInviteSnapshot(guild);
  if (!snapshot) return;

  const state = getInviteState(guild.id);
  state.invites = snapshot;
  state.initialized = true;
  await saveInviteTracker();
}

async function trackMemberJoin(member) {
  if (!member.guild || (member.user && member.user.bot)) return;

  const state = getInviteState(member.guild.id);
  const snapshot = await fetchInviteSnapshot(member.guild);
  if (!snapshot) return;

  if (!state.initialized) {
    state.invites = snapshot;
    state.initialized = true;
    await saveInviteTracker();
    return;
  }

  let matchedInvite = null;
  let largestIncrease = 0;
  Object.keys(snapshot).forEach(code => {
    const previous = state.invites[code];
    const increase = snapshot[code].uses - (previous ? previous.uses || 0 : 0);
    if (increase > largestIncrease && snapshot[code].inviterId) {
      largestIncrease = increase;
      matchedInvite = snapshot[code];
    }
  });

  state.invites = snapshot;
  if (matchedInvite) {
    state.members[member.id] = matchedInvite.inviterId;
  } else {
    delete state.members[member.id];
  }
  await saveInviteTracker();
}

async function trackMemberLeave(member) {
  if (!member.guild) return;

  const state = getInviteState(member.guild.id);
  if (state.members[member.id]) {
    delete state.members[member.id];
    await saveInviteTracker();
  }
}

async function countActiveInvitees(guild, inviterId) {
  const state = getInviteState(guild.id);
  let count = 0;
  let changed = false;

  await Promise.all(
    Object.entries(state.members).map(async ([memberId, memberInviterId]) => {
      if (memberInviterId !== inviterId) return;

      let member = guild.members.cache.get(memberId);
      if (!member) {
        try {
          member = await guild.members.fetch(memberId);
        } catch (error) {
          if (error && (error.code === 10007 || error.status === 404)) {
            delete state.members[memberId];
            changed = true;
          }
          return;
        }
      }
      count += 1;
    })
  );

  if (changed) await saveInviteTracker();
  return count + Number(state.manualInvites[inviterId] || 0);
}

const leaderboardBoards = new Map();

function createLeaderboardEmbed(guild) {
  const state = getInviteState(guild.id);
  const counts = {};

  Object.values(state.members).forEach(inviterId => {
    counts[inviterId] = (counts[inviterId] || 0) + 1;
  });
  Object.entries(state.manualInvites || {}).forEach(([inviterId, bonus]) => {
    counts[inviterId] = (counts[inviterId] || 0) + Number(bonus || 0);
  });

  const rows = Object.entries(counts)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 10)
    .map(([inviterId, count], index) => {
      const member = guild.members.cache.get(inviterId);
      const name = member ? member.user.tag : `<@${inviterId}>`;
      return `**${index + 1}.** ${name} — **${count}** active invitee${count === 1 ? "" : "s"}`;
    });

  return new EmbedBuilder()
    .setTitle("Invite Leaderboard")
    .setDescription(rows.length ? rows.join("\n") : "No tracked active invitees yet.")
    .setColor("#5865F2")
    .setFooter({ text: "Updates every 2 seconds" });
}

async function refreshLeaderboard(board) {
  if (!board || !board.message || board.message.deleted) {
    clearInterval(board.timer);
    leaderboardBoards.delete(board.key);
    return;
  }

  try {
    await board.message.edit({ embeds: [createLeaderboardEmbed(board.guild)] });
  } catch (error) {
    if (error?.code === 10008 || error?.code === 50001 || error?.message?.includes("Unknown Message")) {
      clearInterval(board.timer);
      leaderboardBoards.delete(board.key);
      return;
    }
    throw error;
  }
}

async function sendLeaderboard(e) {
  const key = `${e.guild.id}:${e.channel.id}`;
  const existing = leaderboardBoards.get(key);
  if (existing && !existing.message.deleted) {
    await refreshLeaderboard(existing);
    return;
  }

  const message = await e.channel.send({ embeds: [createLeaderboardEmbed(e.guild)] });
  const board = {
    key,
    guild: e.guild,
    message,
    timer: null
  };
  board.timer = setInterval(() => {
    refreshLeaderboard(board).catch(error =>
      console.error("Could not refresh invite leaderboard:", error)
    );
  }, 2000);
  leaderboardBoards.set(key, board);
}

const giveawayFile = path.join(__dirname, "giveaways.json");
let giveawayData = loadGiveawayData();
let giveawayWrite = Promise.resolve();
const giveawayTimers = new Map();

function loadGiveawayData() {
  try {
    const saved = JSON.parse(fs.readFileSync(giveawayFile, "utf8"));
    return saved && saved.giveaways ? saved : { giveaways: {} };
  } catch (error) {
    return { giveaways: {} };
  }
}

function saveGiveawayData() {
  giveawayWrite = giveawayWrite
    .catch(() => {})
    .then(() =>
      fs.promises.writeFile(giveawayFile, JSON.stringify(giveawayData, null, 2))
    )
    .catch(error => console.error("Could not save giveaways:", error));
  return giveawayWrite;
}

function parseDuration(value) {
  if (!value || typeof value !== "string") return null;

  const input = value.trim().toLowerCase();
  const parts = [...input.matchAll(/(\d+)\s*(s|m|h|d|w)/g)];
  if (
    !parts.length ||
    parts.map(part => part[0]).join("").replace(/\s+/g, "") !== input.replace(/\s+/g, "")
  ) {
    return null;
  }

  const units = { s: 1000, m: 60000, h: 3600000, d: 86400000, w: 604800000 };
  const total = parts.reduce(
    (sum, part) => sum + Number(part[1]) * units[part[2]],
    0
  );

  return total > 0 && total <= 30 * 86400000 ? total : null;
}

function giveawayEmbed(giveaway, ended = false) {
  const requiredInvites = Number(giveaway.requiredInvites || 0);
  const description = ended
    ? giveaway.winnerIds.length
      ? `Winner${giveaway.winnerIds.length === 1 ? "" : "s"}: ${giveaway.winnerIds
          .map(id => `<@${id}>`)
          .join(", ")}`
      : "The giveaway ended without any eligible entries."
    : [
        "React with ✅ to join this giveaway.",
        "React with ❌ to leave it.",
        requiredInvites
          ? `You need at least **${requiredInvites} invite${requiredInvites === 1 ? "" : "s"}** to enter.`
          : "No invite requirement."
      ].join("\n");

  return new EmbedBuilder()
    .setTitle(`🎉 Giveaway: ${giveaway.prize}`)
    .setDescription(description)
    .addFields(
      { name: "Winners", value: String(giveaway.winnerCount), inline: true },
      { name: "Entries", value: String(giveaway.participants.length), inline: true },
      {
        name: "Requirement",
        value: requiredInvites ? `${requiredInvites} invite${requiredInvites === 1 ? "" : "s"}` : "None",
        inline: true
      }
    )
    .setColor(ended ? "#747f8d" : "#5865F2")
    .setFooter({ text: ended ? "Giveaway ended" : "✅ Join • ❌ Leave" })
    .setTimestamp(new Date(giveaway.endsAt));
}

async function getGiveawayMessage(giveaway) {
  const guild = client.guilds.cache.get(giveaway.guildId);
  const channel = guild && guild.channels.cache.get(giveaway.channelId);
  if (!channel || !channel.messages) return null;

  return channel.messages.cache.get(giveaway.messageId) ||
    (await channel.messages.fetch(giveaway.messageId).catch(() => null));
}

async function updateGiveawayMessage(giveaway, ended = false) {
  const message = await getGiveawayMessage(giveaway);
  if (!message) return;

  await message.edit({ embeds: [giveawayEmbed(giveaway, ended)] }).catch(error =>
    console.error("Could not update giveaway message:", error)
  );
}

function scheduleGiveaway(giveaway) {
  const existing = giveawayTimers.get(giveaway.id);
  if (existing) clearTimeout(existing);

  const remaining = giveaway.endsAt - Date.now();
  const delay = Math.max(0, Math.min(remaining, 2147483647));
  const timer = setTimeout(() => {
    if (giveaway.endsAt > Date.now()) {
      scheduleGiveaway(giveaway);
    } else {
      finishGiveaway(giveaway.id).catch(error =>
        console.error("Could not finish giveaway:", error)
      );
    }
  }, delay);
  giveawayTimers.set(giveaway.id, timer);
}

async function finishGiveaway(id) {
  const giveaway = giveawayData.giveaways[id];
  if (!giveaway || giveaway.ended) return;

  giveaway.ended = true;
  giveaway.winnerIds = [];
  const pool = [...new Set(giveaway.participants)];
  while (giveaway.winnerIds.length < Math.min(giveaway.winnerCount, pool.length)) {
    const index = Math.floor(Math.random() * pool.length);
    giveaway.winnerIds.push(pool.splice(index, 1)[0]);
  }

  await saveGiveawayData();
  giveawayTimers.delete(id);
  await updateGiveawayMessage(giveaway, true);

  const message = await getGiveawayMessage(giveaway);
  if (!message) return;

  const winnerText = giveaway.winnerIds.length
    ? giveaway.winnerIds.map(userId => `<@${userId}>`).join(", ")
    : "Nobody";
  await message.channel
    .send(
      `🎉 Giveaway ended for **${giveaway.prize}**! Winner${
        giveaway.winnerIds.length === 1 ? "" : "s"
      }: ${winnerText}`
    )
    .catch(error => console.error("Could not announce giveaway:", error));

  await Promise.all(
    giveaway.winnerIds.map(async userId => {
      const user = await client.users.fetch(userId).catch(() => null);
      if (user) {
        await user.send(`🎉 You won the giveaway for **${giveaway.prize}**!`).catch(() => {});
      }
    })
  );
}

async function restoreGiveaways() {
  await Promise.all(
    Object.values(giveawayData.giveaways).map(async giveaway => {
      giveaway.participants = [...new Set(giveaway.participants || [])];
      giveaway.winnerIds = giveaway.winnerIds || [];
      if (giveaway.ended) return;
      if (giveaway.endsAt <= Date.now()) {
        await finishGiveaway(giveaway.id);
      } else {
        scheduleGiveaway(giveaway);
      }
    })
  );
}

async function startGiveaway(e, args) {
  if (!e.guild || !e.member.permissions.has("MANAGE_GUILD")) {
    await e.channel.send("Only members with Manage Server can start giveaways.");
    return;
  }

  if (args.length < 5 || args[0].toLowerCase() !== "start") {
    await e.channel.send(
      "Usage: `!giveaway start <duration> <winners> <prize> <invites>` (example: `!giveaway start 2h 1 Nitro 2`)"
    );
    return;
  }

  const duration = parseDuration(args[1]);
  const winnerCount = Number(args[2]);
  const requiredInvites = Number(args[args.length - 1]);
  const prize = args.slice(3, -1).join(" ").trim();

  if (
    !duration ||
    !Number.isInteger(winnerCount) ||
    winnerCount < 1 ||
    winnerCount > 50 ||
    !Number.isInteger(requiredInvites) ||
    requiredInvites < 0 ||
    !prize
  ) {
    await e.channel.send(
      "Invalid giveaway options. Use a duration like `30m`, a whole-number winner count, a prize, and a non-negative invite requirement."
    );
    return;
  }

  const id = `${e.guild.id}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
  const giveaway = {
    id,
    guildId: e.guild.id,
    channelId: e.channel.id,
    messageId: null,
    prize,
    winnerCount,
    requiredInvites,
    endsAt: Date.now() + duration,
    participants: [],
    winnerIds: [],
    ended: false
  };

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId(`giveaway:join:${id}`)
      .setLabel("Join")
      .setStyle(ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId(`giveaway:leave:${id}`)
      .setLabel("Leave")
      .setStyle(ButtonStyle.Danger)
  );

  const message = await e.channel.send({ embeds: [giveawayEmbed(giveaway)], components: [row] });
  giveaway.messageId = message.id;
  giveawayData.giveaways[id] = giveaway;
  await saveGiveawayData();
  scheduleGiveaway(giveaway);
}

async function handleGiveawayButton(interaction, action, giveawayId) {
  if (!interaction || !interaction.isButton()) return;

  await interaction.deferReply({ ephemeral: true }).catch(() => {});

  const giveaway = giveawayData.giveaways[giveawayId];
  if (!giveaway || giveaway.ended) {
    await interaction.editReply({ content: "This giveaway has ended." }).catch(() => {});
    return;
  }

  const guild = interaction.guild;
  const user = interaction.user;
  const inviteCount = await countActiveInvitees(guild, user.id);

  if (action === "leave") {
    giveaway.participants = giveaway.participants.filter(id => id !== user.id);
    await saveGiveawayData();
    await interaction.editReply({ content: `You left the giveaway for **${giveaway.prize}**.` }).catch(() => {});
    await updateGiveawayMessage(giveaway);
    return;
  }

  if (inviteCount < giveaway.requiredInvites) {
    await interaction.editReply({
      content: `You do not have enough invites for **${giveaway.prize}**. You have ${inviteCount}; you need ${giveaway.requiredInvites}.`
    }).catch(() => {});
    return;
  }

  if (!giveaway.participants.includes(user.id)) {
    giveaway.participants.push(user.id);
    await saveGiveawayData();
    await interaction.editReply({
      content: `You have ${inviteCount} invite${inviteCount === 1 ? "" : "s"} and qualify for **${giveaway.prize}**. You are entered!`
    }).catch(() => {});
    await updateGiveawayMessage(giveaway);
    return;
  }

  await interaction.editReply({ content: `You are already entered in **${giveaway.prize}**.` }).catch(() => {});
}

async function handleGiveawayReaction(reaction, user) {
  if (!reaction || !user || user.bot) return;
  if (!["✅", "❌"].includes(reaction.emoji.name)) return;

  if (reaction.partial) await reaction.fetch().catch(() => {});
  let message = reaction.message;
  if (message.partial) {
    message = await message.fetch().catch(() => null);
  }
  if (!message) return;
  const giveaway = Object.values(giveawayData.giveaways).find(
    item => item.messageId === message.id
  );
  if (!giveaway) return;

  if (giveaway.ended) {
    await reaction.users.remove(user.id).catch(() => {});
    return;
  }

  if (reaction.emoji.name === "❌") {
    giveaway.participants = giveaway.participants.filter(id => id !== user.id);
    await saveGiveawayData();
    await reaction.users.remove(user.id).catch(() => {});
    await user.send(`You left the giveaway for **${giveaway.prize}**.`).catch(() => {});
    await updateGiveawayMessage(giveaway);
    return;
  }

  const guild = message.guild;
  const inviteCount = await countActiveInvitees(guild, user.id);
  if (inviteCount < giveaway.requiredInvites) {
    await user.send(
      `You do not have enough invites for **${giveaway.prize}**. You have ${inviteCount}; you need ${giveaway.requiredInvites}.`
    ).catch(() => {});
    await reaction.users.remove(user.id).catch(() => {});
    return;
  }

  if (!giveaway.participants.includes(user.id)) {
    giveaway.participants.push(user.id);
    await saveGiveawayData();
    await user.send(
      `You have ${inviteCount} invite${inviteCount === 1 ? "" : "s"} and qualify for **${giveaway.prize}**. You are entered!`
    ).catch(() => {});
    await updateGiveawayMessage(giveaway);
  }
  await reaction.users.remove(user.id).catch(() => {});
}

async function addManualInvites(e, args) {
  if (!e.guild || !e.member.permissions.has("MANAGE_GUILD")) {
    await e.channel.send("Only members with Manage Server can add invites.");
    return;
  }

  const amount = Number(args[0]);
  let target = e.mentions.users.first();
  if (!target && args[1]) {
    const member = e.guild.members.cache.find(
      candidate =>
        candidate.id === args[1] ||
        candidate.user.username.toLowerCase() === args[1].toLowerCase() ||
        candidate.displayName.toLowerCase() === args[1].toLowerCase()
    );
    target = member && member.user;
  }

  if (!Number.isInteger(amount) || amount < 1 || !target) {
    await e.channel.send("Usage: `!add invite <number> <user>`");
    return;
  }

  const state = getInviteState(e.guild.id);
  state.manualInvites[target.id] = Number(state.manualInvites[target.id] || 0) + amount;
  await saveInviteTracker();
  await e.channel.send(
    `Added **${amount}** invite${amount === 1 ? "" : "s"} to ${target}. Their giveaway invite total is now **${await countActiveInvitees(
      e.guild,
      target.id
    )}**.`
  );
}

async function nitrogenerator(e, t, templateName = "testingboost.html") {
  const a = formatAMPM(new Date());
  const n = formatAMPM(new Date(Date.now() - 6e4));
  let o = await fs.readFileSync(`${__dirname}/${templateName}`, "utf8");

  let targetUser = e.mentions.users.first() || e.author;
  const rawTarget = t[0] || "";

  if (!e.mentions.users.first() && rawTarget && e.guild) {
    const member = e.guild.members.cache.find(
      m =>
        m.user.username.toLowerCase() === rawTarget.toLowerCase() ||
        m.displayName.toLowerCase() === rawTarget.toLowerCase() ||
        `${m.user.username}#${m.user.discriminator}`.toLowerCase() === rawTarget.toLowerCase()
    );
    if (member) {
      targetUser = member.user;
    }
  }

  const mentionToken = `<@${targetUser.id}>`;
  const mentionTokenAlt = `<@!${targetUser.id}>`;
  const filteredArgs = t.filter(
    arg =>
      arg !== mentionToken &&
      arg !== mentionTokenAlt &&
      arg.toLowerCase() !== rawTarget.toLowerCase()
  );
  const targetName = (e.guild && e.guild.members.cache.get(targetUser.id)?.displayName) || targetUser.username;
  const targetMessage = filteredArgs.length ? filteredArgs.join(" ") : "Thanks for the invite!";

  datatosend = o;
  datatosend = datatosend.replace(
    "FIRSTAUTHORURL",
    e.author.displayAvatarURL({ extension: "png", size: 256 })
  );
  datatosend = datatosend.replace("THEFIRSTAUTHOR", e.author.username);
  datatosend = datatosend.replace(
    "SECONDAUTHORURL",
    targetUser.displayAvatarURL({ extension: "png", size: 256 })
  );
  datatosend = datatosend.replace("THESECONDAUTHOR", targetName);
  datatosend = datatosend.replace("RESPONSETONITRO", targetMessage);
  datatosend = datatosend.replace("FIRSTAUTHORDATE", "Today at " + n);
  datatosend = datatosend.replace("SECONDAUTHORDATE", "Today at " + a);
  datatosend = datatosend.split("http://localhost:3000/font").join(`http://localhost:${port}/font`);
  datatosend = datatosend
    .split("https://cdn.discordapp.com/attachments/782434583974248511/793316025244057630/nitroregular.png")
    .join(`http://localhost:${port}/${templateName === "testing.html" ? "nitroclassic" : "nitroboost"}.png`);

  const { default: puppeteer } = await import("puppeteer");
  const browser = await puppeteer.launch({
    args: ["--no-sandbox", "--disable-setuid-sandbox"]
  });

  let c;
  try {
    const page = await browser.newPage();
    await page.goto(`http://localhost:${port}`, { waitUntil: "networkidle0" });
    await page.waitForSelector(".scrollerInner-2YIMLh");
    await page.evaluate(() =>
      Promise.all(
        Array.from(document.images).map(image =>
          image.complete
            ? Promise.resolve()
            : new Promise(resolve => {
                image.addEventListener("load", resolve, { once: true });
                image.addEventListener("error", resolve, { once: true });
              })
        )
      )
    );
    const messageList = await page.$(".scrollerInner-2YIMLh");
    c = await messageList.screenshot({ type: "png" });
  } finally {
    await browser.close();
  }

  const imgBuffer = Buffer.isBuffer(c) ? c : Buffer.from(c || []);
  if (!imgBuffer || imgBuffer.length === 0) {
    throw new Error("Puppeteer screenshot returned an empty image buffer.");
  }

  const attachment = new AttachmentBuilder(imgBuffer, { name: "NitroProof.png" });
  await e.channel.send({ content: `${e.author}`, files: [attachment] });
}

process.on("SIGINT", () => renderServer.close(() => process.exit(0)));
process.on("SIGTERM", () => renderServer.close(() => process.exit(0)));

function formatAMPM(e) {
  let t = e.getHours();
  const a = e.getMinutes();
  let n = t >= 12 ? "PM" : "AM";
  t = (t %= 12) || 12;
  return `${t}:${String(a).padStart(2, "0")} ${n}`;
}

const PANEL_TITLE = "Server Invites Checker";
const PANEL_FOOTER = "React with 🎟️ to check your invites";

async function handleInvitePanelReaction(reaction, user) {
  if (!reaction || !user || user.bot || reaction.emoji.name !== "🎟️") return;

  try {
    if (reaction.partial) await reaction.fetch();

    let panelMessage = reaction.message;
    if (panelMessage.partial) panelMessage = await panelMessage.fetch();

    const panelEmbed = panelMessage.embeds && panelMessage.embeds[0];
    if (
      !panelMessage.guild ||
      !panelEmbed ||
      panelEmbed.title !== PANEL_TITLE ||
      !panelEmbed.footer ||
      panelEmbed.footer.text !== PANEL_FOOTER
    ) {
      return;
    }

    const guild = panelMessage.guild;
    const channel = panelMessage.channel;
    const guildMember =
      guild.members.cache.get(user.id) ||
      (await guild.members.fetch(user.id).catch(() => null));
    if (!guildMember) return;

    const inviteCount = await countActiveInvitees(guild, user.id);

    const result = await channel.send({
      embeds: [
        new EmbedBuilder()
          .setTitle(`${user.tag}'s Invites`)
          .setDescription(`You currently have ${inviteCount} active invite${inviteCount === 1 ? "" : "s"}.`)
          .setColor("#43b581")
          .setFooter({ text: "React with ❌ to dismiss" })
      ]
    });

    await result.react("❌");
    const dismissFilter = (r, u) =>
      r.emoji.name === "❌" && !u.bot && r.message.id === result.id && u.id === user.id;
    const dismissCollector = result.createReactionCollector({ filter: dismissFilter });
    dismissCollector.on("collect", async () => {
      await result.delete().catch(() => {});
    });

    await reaction.users.remove(user.id).catch(() => {});
  } catch (error) {
    console.error("Invite panel reaction failed:", error);
  }
}

async function sendInvitePanel(e) {
  const panel = new EmbedBuilder()
    .setTitle(PANEL_TITLE)
    .setDescription("Check your invites to claim a reward")
    .setColor("#5865F2")
    .setFooter({ text: PANEL_FOOTER });

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId("invite_panel:check")
      .setLabel("Check Invites")
      .setStyle(ButtonStyle.Primary)
  );

  await e.channel.send({ embeds: [panel], components: [row] });
}

async function sendNitroRequestPanel(e) {
  const panel = new EmbedBuilder()
    .setTitle("Nitro request")
    .setDescription("Wanna claim your nitro for invites? Click below.")
    .setColor("#5865F2")
    .setFooter({ text: "Click to claim" });

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId("nitro_panel:claim")
      .setLabel("Claim Nitro")
      .setStyle(ButtonStyle.Success)
  );

  await e.channel.send({ embeds: [panel], components: [row] });
}

async function registerSlashCommands() {
  if (!client.user) return;

  const rest = new REST({ version: "10" }).setToken(config.token);
  const guildId = config.guildId;
  const route = guildId
    ? Routes.applicationGuildCommands(client.user.id, guildId)
    : Routes.applicationCommands(client.user.id);

  try {
    await rest.put(route, { body: PANEL_COMMANDS.map(command => ({
      ...command,
      type: 1
    })) });
    console.log("Slash commands registered.");
  } catch (error) {
    console.error("Could not register slash commands:", error);
  }
}

client.on("interactionCreate", async interaction => {
  if (interaction.isChatInputCommand()) {
    const commandName = interaction.commandName.toLowerCase();
    try {
      if (commandName === "panel") {
        await sendInvitePanel({ channel: interaction.channel, guild: interaction.guild, member: interaction.member });
        await interaction.reply({ content: "Invite panel sent.", ephemeral: true });
        return;
      }
      if (commandName === "panel-2") {
        await sendNitroRequestPanel({ channel: interaction.channel, guild: interaction.guild, member: interaction.member });
        await interaction.reply({ content: "Nitro panel sent.", ephemeral: true });
        return;
      }
      if (commandName === "leaderboard") {
        await sendLeaderboard({ channel: interaction.channel, guild: interaction.guild, member: interaction.member });
        await interaction.reply({ content: "Leaderboard sent.", ephemeral: true });
        return;
      }
      if (commandName === "dock") {
        const dockChannel = await ensureDockChannel(interaction.guild, interaction.channel);
        if (!dockChannel) {
          await interaction.reply({ content: "I could not create the dock channel.", ephemeral: true });
          return;
        }

        await interaction.reply({
          content: `Dock channel ready: ${dockChannel}`,
          ephemeral: true
        });
        return;
      }
      if (commandName === "giveaway") {
        const subcommand = interaction.options.getSubcommand();
        if (subcommand === "start") {
          const duration = interaction.options.getString("duration");
          const winners = interaction.options.getInteger("winners");
          const prize = interaction.options.getString("prize");
          const invites = interaction.options.getInteger("invites");
          await interaction.reply({ content: "Starting giveaway...", ephemeral: true });
          await startGiveaway(
            {
              guild: interaction.guild,
              member: interaction.member,
              channel: interaction.channel,
              author: interaction.user
            },
            ["start", duration, String(winners), prize, String(invites)]
          );
          return;
        }
      }
    } catch (error) {
      console.error("Slash command failed:", error);
      await interaction.reply({ content: "This command failed.", ephemeral: true }).catch(() => {});
    }
    return;
  }

  if (!interaction.isButton()) return;

  if (interaction.customId.startsWith("giveaway:")) {
    const [type, action, giveawayId] = interaction.customId.split(":");
    if (type === "giveaway") {
      await handleGiveawayButton(interaction, action, giveawayId);
    }
    return;
  }

  if (interaction.customId === "invite_panel:check") {
    try {
      await interaction.deferReply({ ephemeral: true }).catch(() => {});

      const guildMember =
        interaction.guild.members.cache.get(interaction.user.id) ||
        (await interaction.guild.members.fetch(interaction.user.id).catch(() => null));
      if (!guildMember) return;

      const inviteCount = await countActiveInvitees(interaction.guild, interaction.user.id);

      await interaction.editReply({
        embeds: [
          new EmbedBuilder()
            .setTitle(`${interaction.user.tag}'s Invites`)
            .setDescription(`You currently have ${inviteCount} active invite${inviteCount === 1 ? "" : "s"}.`)
            .setColor("#43b581")
        ]
      });
    } catch (error) {
      console.error("Invite panel button failed:", error);
    }
    return;
  }

  if (interaction.customId === "nitro_panel:claim") {
    try {
      await interaction.deferReply({ ephemeral: true }).catch(() => {});

      const guildMember =
        interaction.guild.members.cache.get(interaction.user.id) ||
        (await interaction.guild.members.fetch(interaction.user.id).catch(() => null));
      if (!guildMember) return;

      const inviteCount = await countActiveInvitees(interaction.guild, interaction.user.id);
      const message = buildNitroClaimMessage(interaction.user, inviteCount);

      await interaction.user.send({
        embeds: [
          new EmbedBuilder()
            .setTitle("Nitro")
            .setDescription(message)
            .setColor(inviteCount >= 2 ? "#43b581" : "#ff5555")
        ]
      });
      await interaction.editReply({ content: "I sent the Nitro status in your DMs." }).catch(() => {});
    } catch (error) {
      console.error("Nitro claim button failed:", error);
    }
    return;
  }
});

client.on("messageReactionAdd", handleGiveawayReaction);
client.on("messageReactionAdd", handleInvitePanelReaction);
client.on("messageReactionAdd", async (reaction, user) => {
  if (!reaction || !user || user.bot || reaction.emoji.name !== "🎟️") return;
  try {
    if (reaction.partial) await reaction.fetch();
    let panelMessage = reaction.message;
    if (panelMessage.partial) panelMessage = await panelMessage.fetch();

    const panelEmbed = panelMessage.embeds && panelMessage.embeds[0];
    if (
      !panelMessage.guild ||
      !panelEmbed ||
      panelEmbed.title !== "Nitro request" ||
      !panelEmbed.footer ||
      panelEmbed.footer.text !== "Click to claim"
    ) {
      return;
    }

    const guildMember =
      panelMessage.guild.members.cache.get(user.id) ||
      (await panelMessage.guild.members.fetch(user.id).catch(() => null));
    if (!guildMember) return;

    const inviteCount = await countActiveInvitees(panelMessage.guild, user.id);
    const message =
      inviteCount >= 2
        ? `Hello ${user}, your Nitro is on the way. Because there is a lot of demand, the owners will manually send your Nitro link as soon as possible.`
        : `Sorry, you don't have enough active invites to claim Nitro. You currently have ${inviteCount}; you need 2.`;

    await user.send({
      embeds: [
        new EmbedBuilder()
          .setTitle("Nitro")
          .setDescription(message)
          .setColor(inviteCount >= 2 ? "#43b581" : "#ff5555")
      ]
    });
    await reaction.users.remove(user.id).catch(() => {});
  } catch (error) {
    console.error("Nitro claim reaction failed:", error);
  }
});

client.on("guildMemberAdd", member => {
  trackMemberJoin(member).catch(error =>
    console.error("Could not track member join:", error)
  );

  const dockChannelId = dockChannels.get(member.guild.id);
  if (!dockChannelId) return;

  const channel = member.guild.channels.cache.get(dockChannelId);
  if (channel && channel.type === ChannelType.GuildVoice) {
    updateDockChannel(channel).catch(() => {});
  }
});

client.on("guildMemberRemove", member => {
  trackMemberLeave(member).catch(error =>
    console.error("Could not track member leave:", error)
  );

  const dockChannelId = dockChannels.get(member.guild.id);
  if (!dockChannelId) return;

  const channel = member.guild.channels.cache.get(dockChannelId);
  if (channel && channel.type === ChannelType.GuildVoice) {
    updateDockChannel(channel).catch(() => {});
  }
});

client.on("voiceStateUpdate", async (oldState, newState) => {
  const guild = newState.guild || oldState.guild;
  if (!guild) return;

  const dockChannelId = dockChannels.get(guild.id);
  if (!dockChannelId) return;

  const channel = guild.channels.cache.get(dockChannelId) || await guild.channels.fetch(dockChannelId).catch(() => null);
  if (!channel || channel.type !== ChannelType.GuildVoice) {
    dockChannels.delete(guild.id);
    return;
  }

  await updateDockChannel(channel);
});

client.on("channelDelete", channel => {
  if (channel && channel.type === ChannelType.GuildVoice && dockChannels.get(channel.guild.id) === channel.id) {
    dockChannels.delete(channel.guild.id);
  }
});

client.once("ready", () => {
  function randomStatus() {
    const status = [
      "Infinite Codes In Stock",
      "Working On nitro ",
      "ifwharsh is my daddy",
      "Invite Me:  >invite"
    ];
    const rstatus = Math.floor(Math.random() * status.length);

    client.user.setPresence({
      activities: [{ name: status[rstatus], type: ActivityType.Playing }],
      status: "online"
    });
  }

  setInterval(randomStatus, 5000);

  client.guilds.cache.forEach(guild => {
    initializeInviteTracking(guild).catch(error =>
      console.error("Could not initialize invite tracking:", error)
    );
  });
  restoreGiveaways().catch(error =>
    console.error("Could not restore giveaways:", error)
  );
  registerSlashCommands().catch(error =>
    console.error("Could not register slash commands:", error)
  );

  console.log("Online.");
});

client.on("messageCreate", async e => {
  if (e.channel.type === ChannelType.DM) return;
  if (e.author.bot) return;

  if (e.channel.id === ANNOUNCEMENTS_CHANNEL_ID) {
    const announcementRole = getAnnouncementsRole(e.guild);
    if (announcementRole) {
      await e.channel.send({ content: `<@&${announcementRole.id}>` }).catch(() => {});
    }
  }

  if (e.channel.id === PROOF_CHANNEL_ID) {
    const proofRole = getProofRole(e.guild);
    if (proofRole) {
      await e.channel.send({ content: `<@&${proofRole.id}>` }).catch(() => {});
    }
  }

  const rawCommand = e.content.trim().split(/ +/g);
  if (rawCommand[0] && rawCommand[0].toLowerCase() === "!giveaway") {
    await startGiveaway(e, rawCommand.slice(1)).catch(error =>
      console.error("Could not create giveaway:", error)
    );
    return;
  }
  if (
    rawCommand[0] &&
    rawCommand[0].toLowerCase() === "!add" &&
    rawCommand[1] &&
    rawCommand[1].toLowerCase() === "invite"
  ) {
    await addManualInvites(e, rawCommand.slice(2)).catch(error =>
      console.error("Could not add manual invites:", error)
    );
    return;
  }

  if (e.content.indexOf(config.prefix) !== 0) return;
  const t = e.content
    .slice(config.prefix.length)
    .trim()
    .split(/ +/g);
  const command = t.shift();

  if (command && command.toLowerCase() === "boost") {
    await nitrogenerator(e, t).catch(error =>
      console.error("Could not generate boost image:", error)
    );
    return;
  }

  if (command && command.toLowerCase() === "classic") {
    await nitrogenerator(e, t, "testing.html").catch(error =>
      console.error("Could not generate classic image:", error)
    );
  }
});

client.login(config.token);
